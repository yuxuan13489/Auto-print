#ifndef DEFINE_H
#define DEFINE_H

#define CHECK_SPEED 2000
#define ICON_PATH ":/res/print.png"

#endif // DEFINE_H
